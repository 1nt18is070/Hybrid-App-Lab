package com.example.intentactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    EditText number1;
    EditText number2;
    Button Add_Button;
    //TextView result;
    int ans=0;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("lifecycle","onCreate invoked-1");

        number1=(EditText) findViewById(R.id.num1);
        number2=(EditText) findViewById(R.id.num2);
        Add_Button=(Button) findViewById(R.id.btnadd);
        //result=(TextView) findViewById(R.id.);
        intent=new Intent(this,SecondIntent.class);


        Add_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double n1=Double.parseDouble(number1.getText().toString());
                double n2=Double.parseDouble(number2.getText().toString());

                double sum=n1+n2;
                intent.putExtra("value",Double.toString(sum));
                startActivity(intent);
                //result.setText(Double.toString(sum));
            }
        });
    }

    @Override
    protected void onStart()
    {
        super.onStart();
        Log.d("lifecycle","onStart invoked-1");
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        Log.d("lifecycle","onResume invoked-1");
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        Log.d("lifecycle","onPause invoked-1");
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        Log.d("lifecycle","onStop invoked-1");
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();
        Log.d("lifecycle","onRestart invoked-1");
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        Log.d("lifecycle","onDestroy invoked-1");
    }


}