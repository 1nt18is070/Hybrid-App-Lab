package com.example.intentactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class SecondIntent extends AppCompatActivity {

    TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_intent);
        Log.d("lifecycle","onCreate invoked-2");
        result=(TextView) findViewById(R.id.added);
        Intent intent=getIntent();
        String ans= intent.getStringExtra("value");
        result.setText(ans);
    }

    @Override
    protected void onStart()
    {
        super.onStart();
        Log.d("lifecycle","onStart invoked-2");
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        Log.d("lifecycle","onResume invoked-2");
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        Log.d("lifecycle","onPause invoked-2");
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        Log.d("lifecycle","onStop invoked-2");
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();
        Log.d("lifecycle","onRestart invoked-2");
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        Log.d("lifecycle","onDestroy invoked-2");
    }
}